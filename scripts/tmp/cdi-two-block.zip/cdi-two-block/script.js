const structureTabButtons = document.querySelectorAll(".structure .tab-button");
const structureTabContents = document.querySelectorAll(".structure .tab-content");

addActiveExpert(structureTabButtons, structureTabContents);
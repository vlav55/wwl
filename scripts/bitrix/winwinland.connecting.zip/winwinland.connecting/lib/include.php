<?php
\Bitrix\Main\Loader::registerAutoLoadClasses(
    'winwinland.connecting',
    [
        'WWL\\Connecting\\EventHandler' => 'lib/EventHandler.php',
    ]
);

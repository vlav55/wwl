<?php
\Bitrix\Main\Loader::registerAutoLoadClasses(
    'winwinland.connect',
    [
        'WWL\\Connect\\EventHandler' => 'lib/EventHandler.php',
    ]
);

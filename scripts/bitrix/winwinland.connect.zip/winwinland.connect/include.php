<?
require_once __DIR__ . '/lib/include.php';
?>